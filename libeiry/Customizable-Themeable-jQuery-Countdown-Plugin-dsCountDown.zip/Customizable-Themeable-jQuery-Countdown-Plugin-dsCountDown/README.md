dscountdown
===========

Easy and customizable count down plugin for jQuery.

<p>Released under the <a href="http://www.opensource.org/licenses/mit-license.php">MIT License.</a><br>
		Compatible with: jQuery 1.2.3+ in Firefox, Safari, Chrome, Opera, Internet Explorer 7+</p>

See the <a href="http://iwayanwirka.duststone.com/dscountdown/" target="_blank">project page</a> for documentation and a demonstration.

<h2 id="changelog">Changelog</h2>
<h3>Version 1.0 - 12 November 2013</h3>
<ul>
<li>Initial release.</li>
</ul>
